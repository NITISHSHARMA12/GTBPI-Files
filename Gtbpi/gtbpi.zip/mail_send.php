<?php

if(isset($_POST['InputEmail'])) {
  
    // EDIT THE 2 LINES BELOW AS REQUIRED
    $to = "info@gtbpi.in";
    $email_subject = "Gtbpi Feedback";
     
  
    $name = $_POST['InputName']; // required
    $email_from = $_POST['InputEmail']; // required
    $telephone = $_POST['InputContact']; // not required
    $comments = $_POST['InputComment']; // required
 
     
    function clean_string($string) {
      $bad = array("content-type","bcc:","to:","cc:","href");
      return str_replace($bad,"",$string);
    }
    function goback()
    {
        header("Location: {$_SERVER['HTTP_REFERER']}");
        exit;
    }
     
 
    $email_message = " <!DOCTYPE html> <html>
<body>
<p><span>Dear</span> Gtbpi,</p>
<div style='padding-bottom:25px;padding-left:35px;padding-right:35px;'><p>$comments</p>
<p>Please go to the following URL to visit Facebook page:-</p>
<a href='https://www.facebook.com/GuruTeghBahadurPolytechnicInstitute/'>https://www.facebook.com/GuruTeghBahadurPolytechnicInstitute</a>
</div>
<div style='padding-left:35px;'><p style='padding:5px;margin:0px;'><b>$name</b></p>
<p style='margin:0px; padding-left:5px;'>$telephone</p></div>
</body>
</html>";
 
// create email headers
$headers .= 'MIME-Version: 1.0' . "\r\n";
$headers  .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

$headers .= 'From: '.$email_from."\r\n".
'Reply-To: '.$email_from."\r\n" .
'X-Mailer: PHP/' . phpversion();
mail($to, $email_subject, $email_message, $headers);  
?>

 
<?php
goback();
}
?>